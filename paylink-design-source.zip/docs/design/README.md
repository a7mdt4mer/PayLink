# PayLink Phase 1 Design Pack

Six editable PlantUML source files:
1. use-case.puml
2. domain-class.puml
3. pay-a-bill-sequence.puml
4. refund-failed-payment-sequence.puml
5. payment-state.puml
6. database-er.puml

## Render
Open each `.puml` file with a PlantUML-compatible editor or use the PlantUML extension in VS Code.
These are source files, not screenshots. Keep them under `docs/design/` in the repository.

## Important modelling notes
- Payment states and allowed transitions follow Section 2.5 of the supplied PayLink brief.
- Unknown payments keep funds held; they are not automatically refunded.
- Failed becomes Refunded only after the held funds are released.
- Wallet movements are represented by ledger entries; balances are derived from the ledger.
- Review names/fields against your team's final requirements and implementation before submission.
